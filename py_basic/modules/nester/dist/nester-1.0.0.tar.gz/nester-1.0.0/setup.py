from distutils.core import setup

setup(
    name='nester',
    version='1.0.0',
    py_modules=['nester'],
    author='ykjang',
    author_email='yongkyu.jang@gmail.com',
    url='http://www.headfirstlabs.com',
    description='A Simple printer of nested lists'
)